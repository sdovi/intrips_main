import { useEffect, useState } from "react";
import axios from "axios";

const AgreementPage = ({ shopUrl }) => {
    const [categories, setCategories] = useState([]);
    const [cards, setCards] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        const fetchData = async () => {
            try {
                const [categoriesRes, cardsRes] = await Promise.all([
                    axios.get(`https://intrips.site/api/${shopUrl}/agreement_categories/`),
                    axios.get(`https://intrips.site/api/${shopUrl}/info_cards/`)
                ]);
                
                setCategories(categoriesRes.data);
                setCards(cardsRes.data);
                setLoading(false);
            } catch (err) {
                setError("Ошибка загрузки данных");
                setLoading(false);
            }
        };

        fetchData();
    }, [shopUrl]);

    if (loading) return <p>Загрузка...</p>;
    if (error) return <p style={{ color: "red" }}>{error}</p>;

    return (
        <div style={{ padding: "20px", maxWidth: "800px", margin: "auto" }}>
            <h1 style={{ textAlign: "center", color: "#007BFF" }}>
                Соглашения магазина ({shopUrl})
            </h1>

            <h2>Категории</h2>
            <ul style={{ listStyle: "none", padding: 0 }}>
                {categories.map(category => (
                    <li key={category.id} style={{ padding: "10px", borderBottom: "1px solid #ddd" }}>
                        {category.title}
                    </li>
                ))}
            </ul>

            <h2>Карточки</h2>
            <div style={{ display: "grid", gap: "10px" }}>
                {cards.map(card => (
                    <div key={card.id} style={{ border: "1px solid #ddd", padding: "10px", borderRadius: "5px" }}>
                        <img src={card.image} alt={card.bold_text} style={{ width: "100%", borderRadius: "5px" }} />
                        <h3>{card.bold_text}</h3>
                        <p>{card.long_text}</p>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default AgreementPage;
