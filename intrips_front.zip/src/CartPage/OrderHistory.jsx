import React, { useEffect, useState } from "react";
import { Box, Typography, List, ListItem, ListItemText } from "@mui/material";

export default function OrderHistory() {
  const [orderHistory, setOrderHistory] = useState([]);

  useEffect(() => {
    const savedOrders = JSON.parse(localStorage.getItem("orders")) || [];
    setOrderHistory(savedOrders);
  }, []);

  return (
    <div className="container">
      <Box style={{ padding: "16px", textAlign: "center" }}>
        <Typography variant="h6" style={{ marginBottom: "10px" }}>
          История заказов
        </Typography>
        {orderHistory.length === 0 ? (
          <Typography variant="body1">Нет заказов</Typography>
        ) : (
          <List>
            {orderHistory.map((order, index) => (
              <ListItem key={index} divider>
                <ListItemText
                  primary={`Заказ №${index + 1} | Дата: ${order.date} | Сумма: ${order.total_price} ₽ | Магазин ID: ${order.shop}`}
                  secondary={`Товары: ${order.items
                    .map((item) => `${item.name} (x${item.quantity})`)
                    .join(", ")}`}
                />
              </ListItem>
            ))}
          </List>
        )}
      </Box>
    </div>
  );
}
