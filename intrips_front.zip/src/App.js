import React from "react";
import { Routes, Route } from "react-router-dom";
import Main from "./Pages/Main";
import CategoryPage from "./Components/CategoryPage/CategoryPage";
import ViewProduct from "./Components/VIew_product/View_product";
import CartPage from "./CartPage/CartPage";
import ClientChat from "./Components/Chat/ClientChat";
import AdminChat from "./Components/Chat/AdminChat";
import WebSocketChat from "./Components/Chat/ClientChat";
import AgreementDetail from "./Components/Agrement/AgreementDetail";
import RestaurantPage from "./Components/RestaurantPage/RestaurantPage";
import ShopsList from "./Components/Vitrina/ShopsList";
import ShopDetails from "./Components/Vitrina/ShopDetails";
import CategoryDetails from "./Components/Vitrina/CategoryDetails";
import ItemDetails from "./Components/Vitrina/ItemDetails";

function App() {
  return (
    <div className="App">
      <Routes>
        <Route path="/" element={<Main />} />
        <Route path="/category/:id" element={<CategoryPage />} />
        <Route path="/products/:id" element={<ViewProduct />} />
        <Route path="/cart" element={<CartPage />} />
        <Route path="/admin" element={<AdminChat />} />
        <Route path="/chat" element={<WebSocketChat />} />
        <Route path="/:shopUrl/card/:id" element={<AgreementDetail />} />

        {/* Динамическая страница ресторана (по website_url из API) */}
        <Route path="/api/:websiteUrl" element={<RestaurantPage />} />
        <Route path="/shop/:website_url/cart" element={<CartPage />} />

        <Route path="/shop/list" element={<ShopsList />} />
        <Route path="/shop/:website_url" element={<ShopDetails />} />
        <Route path="/shop/:website_url/category/:category_id" element={<CategoryDetails />}/>
        <Route path="/shop/:website_url/category/:category_id/item/:item_id" element={<ItemDetails />} />
      </Routes>
    </div>
  );
}

export default App;
