import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import axios from "axios";

const API_URL = "https://intrips.site"; // Укажи свой API

export default function AgreementDetail() {
  const { shopUrl, id } = useParams(); // 📌 Берем shopUrl из URL
  const navigate = useNavigate();
  const [card, setCard] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!shopUrl || !id) return; // Проверяем, что есть shopUrl

    axios
      .get(`${API_URL}/api/${shopUrl}/info_cards/${id}/`)
      .then((response) => {
        setCard(response.data);
        setLoading(false);
      })
      .catch((error) => {
        console.error("Ошибка загрузки карточки", error);
        setLoading(false);
      });
  }, [shopUrl, id]);

  if (loading) return <h2>Загрузка...</h2>;
  if (!card) return <h2>Карточка не найдена</h2>;

  return (
    <div className="card-detail">
      <div
        className="card-detail__image"
        style={{
          backgroundImage: `url(${API_URL}${card.image})`,
        }}
      >
        <button className="card-detail__back-btn" onClick={() => navigate(-1)}>
          ← 
        </button>
      </div>
      <div className="card-detail__content">
        <h1 className="card-detail__title">{card.bold_text}</h1>
        <p className="card-detail__description">{card.long_text}</p>
      </div>
    </div>
  );
}
