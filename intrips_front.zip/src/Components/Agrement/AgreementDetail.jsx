import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import axios from "axios";

const API_URL = "https://intrips.site"; // Укажи свой API

export default function AgreementDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [card, setCard] = useState(null);

  useEffect(() => {
    axios
      .get(`${API_URL}/api/info_cards/${id}/`)
      .then((response) => {
        console.log(response.data); // Проверяем, что приходит
        setCard(response.data);
      })
      .catch((error) => console.error("Ошибка загрузки карточки", error));
  }, [id]);

  if (!card) return <h2>Загрузка...</h2>;

  return (
    <div className="card-detail">
      <div
        className="card-detail__image"
        style={{
          backgroundImage: `url(${API_URL}${card.image})`,
        }}
      >
        <button className="card-detail__back-btn" onClick={() => navigate(-1)}>
          ←
        </button>
      </div>
      <div className="card-detail__content">
        <h1 className="card-detail__title">{card.bold_text}</h1>
        <p className="card-detail__description">{card.long_text}</p>
        {/* <p className="card-detail__description-en">{card.long_text_en}</p> */}
      </div>
    </div>
  );
}
