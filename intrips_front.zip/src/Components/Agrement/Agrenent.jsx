import React, { useEffect, useState } from "react";
import axios from "axios";
import { Link } from "react-router-dom";
import './style.css';

const API_URL = "https://intrips.site"; // Укажи свой API

export default function AgreementList({ shopUrl }) {
  const [cards, setCards] = useState([]);
  const [category, setCategory] = useState("Список карточек");

  useEffect(() => {
    if (!shopUrl) return;

    axios
      .get(`${API_URL}/api/${shopUrl}/info_cards/`)
      .then((response) => {
        setCards(response.data);
        if (response.data.length > 0) {
          setCategory(response.data[0].category.title);
        }
      })
      .catch((error) => console.error("Ошибка загрузки карточек", error));
  }, [shopUrl]);

  return (
    <div className="secton1">
      <div className="container sect1_container">
        <h5 className="sect1__p1">{category}</h5>
        <div className="sect1__cards mt-3">
          {cards.length > 0 ? (
            cards.map((card) => (
              <Link
                key={card.id}
                to={`/${shopUrl}/card/${card.id}`}  // 📌 УЧТЫВАЕМ shopUrl
                className="sect1__card link Link"
                style={{
                  backgroundImage: `url(${API_URL}${card.image})`,
                  backgroundSize: "cover",
                  backgroundPosition: "center",
                  backgroundRepeat: "no-repeat",
                }}
              >
                <h6 className="agre_h6">{card.bold_text}</h6>
              </Link>
            ))
          ) : (
            <p>Нет доступных карточек.</p>
          )}
        </div>
      </div>
    </div>
  );
}
