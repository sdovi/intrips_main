import React, { useEffect, useState } from "react";
import axios from "axios";
import {
  AppBar,
  Toolbar,
  IconButton,
  Typography,
  Tabs,
  Tab,
  Card,
  CardContent,
  CardMedia,
  Grid,
  Container,
  Badge,
  Button,
} from "@mui/material";
import ArrowBackIcon from "@mui/icons-material/ArrowBack";
import ShoppingCartIcon from "@mui/icons-material/ShoppingCart";
import { useNavigate, useParams } from "react-router-dom";
import { useCart } from "react-use-cart";
import Footer from "../Footer/Footer";
import "./style.css";

export default function ViewProduct() {
  const [categories, setCategories] = useState([]);
  const [menuItems, setMenuItems] = useState([]);
  const [headerText, setHeaderText] = useState("");
  const [selectedCategory, setSelectedCategory] = useState(null);
  const [siteLanguage, setSiteLanguage] = useState(
    localStorage.getItem("siteLanguage") || "ru"
  );
  const { id: categoryId } = useParams();
  const navigate = useNavigate();
  const { addItem, updateItemQuantity, getItem, totalItems } = useCart();
  const [cartItems, setCartItems] = useState({});

  useEffect(() => {
    axios
      .get("https://intrips.site/api/categories/")
      .then((response) => {
        setCategories([
          { id: 0, name: "Все", name_en: "All" },
          ...response.data,
        ]);
      })
      .catch((error) => console.error("Error fetching categories:", error));

    axios
      .get("https://intrips.site/api/menu-items/")
      .then((response) => setMenuItems(response.data))
      .catch((error) => console.error("Error fetching menu items:", error));

    axios
      .get("https://intrips.site/api/header-text/")
      .then((response) => {
        const header = response.data[0];
        setHeaderText(siteLanguage === "en" ? header.name_en : header.name);
      })
      .catch((error) => console.error("Error fetching header text:", error));
  }, [siteLanguage]);

  useEffect(() => {
    if (categoryId) {
      setSelectedCategory(parseInt(categoryId, 10));
    }
  }, [categoryId]);

  const handleAddToCart = (item) => {
    addItem(item);
    setCartItems((prev) => ({ ...prev, [item.id]: 1 }));
  };

  const handleUpdateQuantity = (id, quantity) => {
    if (quantity === 0) {
      setCartItems((prev) => {
        const updatedCart = { ...prev };
        delete updatedCart[id];
        return updatedCart;
      });
    } else {
      setCartItems((prev) => ({ ...prev, [id]: quantity }));
    }
    updateItemQuantity(id, quantity);
  };

  const filteredMenuItems = selectedCategory
    ? menuItems.filter((item) => item.category === selectedCategory)
    : menuItems;

  return (
    <>
      <div className="view__block-main">
        <Container
          maxWidth="sm"
          style={{ padding: "0", backgroundColor: "#f9f9f9" }}
        >
          <AppBar position="static" color="transparent" elevation={0}>
            <Toolbar>
              <IconButton
                edge="start"
                color="inherit"
                aria-label="back"
                onClick={() => navigate(-1)}
              >
                <ArrowBackIcon />
              </IconButton>
              <Typography variant="h6" style={{ flexGrow: 1 }}>
                {headerText}
              </Typography>
              <IconButton
                color="inherit"
                aria-label="cart"
                onClick={() => navigate("/cart")}
              >
                <Badge
                  badgeContent={totalItems}
                  color="error"
                  overlap="circular"
                >
                  <ShoppingCartIcon />
                </Badge>
              </IconButton>
            </Toolbar>
          </AppBar>

          <Tabs
            value={selectedCategory || 0}
            onChange={(event, newValue) => setSelectedCategory(newValue)}
            variant="scrollable"
            scrollButtons="auto"
            aria-label="categories tabs"
            textColor="inherit"
            indicatorColor="primary"
          >
            {categories.map((category) => (
              <Tab
                key={category.id}
                label={siteLanguage === "en" ? category.name_en : category.name}
                value={category.id}
              />
            ))}
          </Tabs>

          <Grid container spacing={2} style={{ padding: "16px" }}>
            {filteredMenuItems.map((item) => {
              const cartItem = getItem(item.id);
              const quantity = cartItem ? cartItem.quantity : 0;

              return (
                <Grid item xs={6} sm={6} key={item.id}>
                  <Card
                    style={{
                      display: "flex",
                      flexDirection: "column",
                      alignItems: "start",
                      backgroundColor: "#F5F5F5",
                      borderRadius: "12px",
                      boxShadow: "none",
                    }}
                  >
                    <CardMedia
                      component="img"
                      style={{
                        width: "100%",
                        height: 140,
                        objectFit: "cover",
                        borderRadius: "8px",
                      }}
                      image={item.photo || "https://via.placeholder.com/100"}
                      alt={item.name}
                      onClick={() => navigate(`/category/${item.id}`)}
                    />
                    <CardContent
                      style={{
                        flex: "1",
                        textAlign: "center",
                        padding: "15px 10px",
                      }}
                    >
                      <Typography
                        variant="h7"
                        style={{ fontWeight: "400", color: "#000" }}
                      >
                        {siteLanguage === "en" ? item.name_en : item.name}
                      </Typography>
                    </CardContent>

                    {quantity > 0 ? (
                      <div
                        style={{
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "center",
                          width: "100%",
                          marginTop: "15px",
                        }}
                      >
                        <Button
                          variant="contained"
                          style={{
                            minWidth: "36px",
                            backgroundColor: "#000",
                            color: "#FFF",
                            borderRadius: "50%",
                          }}
                          onClick={() =>
                            handleUpdateQuantity(item.id, quantity - 1)
                          }
                        >
                          -
                        </Button>
                        <Typography
                          variant="h6"
                          style={{ margin: "0 10px", fontWeight: "700" }}
                        >
                          {quantity}
                        </Typography>
                        <Button
                          variant="contained"
                          style={{
                            minWidth: "36px",
                            backgroundColor: "#000",
                            color: "#FFF",
                            borderRadius: "50%",
                          }}
                          onClick={() =>
                            handleUpdateQuantity(item.id, quantity + 1)
                          }
                        >
                          +
                        </Button>
                      </div>
                    ) : (
                      <Button
                        variant="contained"
                        className="View-product__btn-card"
                        style={{
                          marginTop: "8px",
                          backgroundColor: "#000",
                          color: "#FFF",
                          fontWeight: "700",
                          letterSpacing: "0.75px",
                          fontSize: "18px",
                          borderRadius: "24px",
                        }}
                        onClick={() => handleAddToCart(item)}
                      >
                        {item.price} ₽
                      </Button>
                    )}
                  </Card>
                </Grid>
              );
            })}
          </Grid>
        </Container>
      </div>
      <Footer />
    </>
  );
}
