import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import axios from "axios";

function RestaurantPage() {
  const { websiteUrl } = useParams(); // Получаем параметр из URL
  const [restaurantData, setRestaurantData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    axios
      .get("https://intrips.site/api/all-data/")
      .then((response) => {
        const foundRestaurant = response.data.find(
          (rest) => rest.user_settings.website_url === websiteUrl
        );

        setRestaurantData(foundRestaurant || null);
        setLoading(false);
      })
      .catch((error) => {
        console.error("Ошибка при загрузке данных:", error);
        setLoading(false);
      });
  }, [websiteUrl]);

  if (loading) return <h2>Загрузка...</h2>;
  if (!restaurantData) return <h2>Ресторан не найден</h2>;

  return (
    <div>
      <h1>Ресторан: {restaurantData.user_settings.website_url}</h1>
      <p>Телеграм Бот: {restaurantData.user_settings.tg_bot_token}</p>
      <p>Телеграм Группа: {restaurantData.user_settings.tg_group_id}</p>

      <h2>Категории</h2>
      <ul>
        {restaurantData.categories.map((category) => (
          <li key={category.id}>{category.name}</li>
        ))}
      </ul>

      <h2>Меню</h2>
      <ul>
        {restaurantData.menu_items.map((item) => (
          <li key={item.id}>{item.name} - {item.price} ₽</li>
        ))}
      </ul>
    </div>
  );
}

export default RestaurantPage;
