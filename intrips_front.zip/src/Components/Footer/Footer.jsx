import React, { useState, useEffect, useRef } from "react";
import axios from "axios";
import {
  Box,
  IconButton,
  TextField,
  Button,
  List,
  ListItem,
  ListItemText,
  Badge,
  Typography,
} from "@mui/material";
import ChatIcon from "@mui/icons-material/Chat";
import CloseIcon from "@mui/icons-material/Close";
import { motion } from "framer-motion";
import "./style.css";
import img from './123.svg'

export default function FooterChat({ websiteUrl }) {
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [userId] = useState(() => localStorage.getItem("user_id") || Date.now().toString());
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState("");
  const [unreadCount, setUnreadCount] = useState(0);
  const messagesEndRef = useRef(null);

  useEffect(() => {
    localStorage.setItem("user_id", userId);
    fetchMessages();
    const interval = setInterval(() => {
      fetchMessages();
    }, 10000);
    return () => clearInterval(interval);
  }, [userId, websiteUrl]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const messagesURL = `https://intrips.site/chat/${websiteUrl}/messages/`;
  const unreadCountURL = `https://intrips.site/chat/${websiteUrl}/unread_count/`;

  // Получение сообщений
  const fetchMessages = async () => {
    try {
      const response = await axios.get(messagesURL, { params: { user_id: userId } });
      if (response.data.length > messages.length) {
        setMessages(response.data);
        setUnreadCount(response.data.length - messages.length);
      }
    } catch (err) {
      console.error("Ошибка получения сообщений:", err);
    }
  };

  // Отправка сообщения
  const sendMessage = async () => {
    if (!newMessage.trim()) return;
    try {
      const response = await axios.post(messagesURL, {
        user_id: userId,
        message: newMessage,
        is_admin: false,
      });
      setMessages((prev) => [...prev, response.data]);
      setNewMessage("");
      setUnreadCount(0);
    } catch (err) {
      console.error("Ошибка отправки сообщения:", err);
    }
  };
  return (
    <div className="footer">
      <div className="footer-text">
        <span role="img" aria-label="search">🔍</span>
        <span>Остались вопросы?</span>
      </div>
      <button className="footer-button" onClick={() => setIsChatOpen(!isChatOpen)}>
        Напишите нам
      </button>

      {isChatOpen && (
        <Box sx={{ position: "fixed", bottom: 16, right: 16 }}>
    <Badge badgeContent={unreadCount} color="error" sx={{ mr: 2 }}>
      <IconButton
        onClick={() => setIsChatOpen(!isChatOpen)}
        sx={{
          backgroundColor: "primary.main",
          color: "white",
          "&:hover": { backgroundColor: "primary.dark" },
        }}
      >
        {isChatOpen ? <CloseIcon /> : <ChatIcon />}
      </IconButton>
    </Badge>

    {isChatOpen && (
      <Box
        sx={{
          position: "fixed",
          top: 0,
          left: 0,
          width: "100vw",
          height: "100vh",
          backgroundColor: "rgba(0, 0, 0, 0.5)",
          zIndex: 1200,
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
        }}
        onClick={() => setIsChatOpen(false)}
      >
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.8 }}
          onClick={(e) => e.stopPropagation()}
        >
          <Box
            sx={{
              p: 2,
              boxShadow: 2,
              borderRadius: 2,
              backgroundColor: "background.paper",
              display: "flex",
              flexDirection: "column",
              maxHeight: "80vh",
              overflowY: "auto",
              width: "100%",
              maxWidth: 400,
            }}
          >
            <Typography variant="h6" sx={{ textAlign: "center", mb: 1, fontWeight: "bold" }}>
              Чат магазина {websiteUrl}
            </Typography>
            <List sx={{ overflowY: "auto", flexGrow: 1 }}>
              {messages.map((msg, idx) => (
                <ListItem key={idx}>
                  <ListItemText
                    primary={msg.message}
                    secondary={msg.is_admin ? "Администратор" : "Вы"}
                  />
                </ListItem>
              ))}
              <div ref={messagesEndRef} />
            </List>
            <Box sx={{ display: "flex", mt: 2 }}>
              <TextField
                fullWidth
                value={newMessage}
                onChange={(e) => setNewMessage(e.target.value)}
                placeholder="Введите сообщение"
                variant="outlined"
                size="small"
              />
              <Button variant="contained" onClick={sendMessage} sx={{ ml: 1 }}>
                Отправить
              </Button>
            </Box>
          </Box>
        </motion.div>
      </Box>
    )}
  </Box>
      )}

      <div className="footer-made-by">
      
        <br />
        <span>Made in </span>
        <img src={img} alt="Made in Logo" className="footer-logo" />
      </div>
    </div>
  );
}