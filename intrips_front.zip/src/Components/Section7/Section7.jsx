import React from 'react'

export default function Section7() {
  return (
    <div>
    
    </div>
  )
}
