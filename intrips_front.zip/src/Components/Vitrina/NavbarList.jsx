import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { IconButton, Modal, Box, Button, Stack, InputBase, CircularProgress, Typography, Container } from "@mui/material";
import { Language as GlobeIcon, Close as CloseIcon, Search as SearchIcon } from "@mui/icons-material";
import Flag from "react-world-flags";
import axios from "axios";
import "./stylenav.css";

const NavbarList = ({ imgUrl, headerText, siteLanguage, setSiteLanguage, websiteUrl  }) => {
    const [open, setOpen] = useState(false);
    const [isSearchOpen, setIsSearchOpen] = useState(false);
    const [searchQuery, setSearchQuery] = useState("");
    const [menuItems, setMenuItems] = useState([]);
    const [filteredResults, setFilteredResults] = useState([]);
    const [isLoading, setIsLoading] = useState(false);
    const navigate = useNavigate();
    const [allItems, setAllItems] = useState([]);

    // Открытие / Закрытие модального окна выбора языка
    const handleOpen = () => setOpen(true);
    const handleClose = () => setOpen(false);

    // Открытие / Закрытие поиска
    const openSearchMenu = () => setIsSearchOpen(true);
    const closeSearchMenu = () => {
        setIsSearchOpen(false);
        setSearchQuery("");
        setFilteredResults([]);
    };

    // Загрузка товаров при открытии поиска
    useEffect(() => {
        if (isSearchOpen) {
            setIsLoading(true);
            axios
                .get("https://intrips.site/api/menu-items/")
                .then((response) => {
                    setMenuItems(response.data);
                    setIsLoading(false);
                })
                .catch((error) => {
                    console.error("Ошибка загрузки товаров:", error);
                    setIsLoading(false);
                });
        }
    }, [isSearchOpen]);
    useEffect(() => {
        axios.get("https://intrips.site/api/all-data/")
            .then((response) => {
                console.log("Данные из API:", response.data);
                
                // Собираем все товары из всех магазинов
                const items = response.data.flatMap(shop => 
                    shop.menu_items.map(item => ({
                        id: item.id,
                        name: item.name,
                        price: item.price,
                        website_url: shop.user_settings.website_url, // ✅ Берём URL магазина
                        category_id: item.category_id, // ✅ Добавляем категорию
                    }))
                );
    
                setAllItems(items);
            })
            .catch((error) => console.error("Ошибка загрузки данных:", error));
    }, []);
    
    const handleSearchChange = (event) => {
        const query = event.target.value.toLowerCase();
        setSearchQuery(query);
    
        if (!query) {
            setFilteredResults([]);
            return;
        }
    
        const results = allItems
            .filter((item) => item.name.toLowerCase().includes(query))
            .map((item) => ({
                id: item.id,
                name: item.name,
                price: item.price,
                website_url: item.website_url, 
                category_id: item.category_id, 
            }));
    
        setFilteredResults(results);
    };
    
    

    return (
        <div>
            <nav>
                <div
                    className="nav_img"
                    style={{
                        background: `linear-gradient(rgba(0, 0, 0, 0.2), rgba(0, 0, 0, 0.7)), url(${imgUrl})`,
                        backgroundSize: "cover",
                        backgroundPosition: "center center",
                        backgroundRepeat: "no-repeat",
                    }}
                >
                    <div className="container navbar_block-top">
                        <Link to={`/shop/${websiteUrl}/cart`}>
                            <div className="nav__logo-profile">
                                <svg xmlns="http://www.w3.org/2000/svg" width="38" height="38" viewBox="0 0 32 32">
                                    <g fill="none" stroke="currentColor" strokeWidth="2">
                                        <circle cx="16" cy="16" r="11"></circle>
                                        <circle cx="16" cy="14" r="4"></circle>
                                        <path d="M23.357 24.034a7.503 7.503 0 00-14.714.001"></path>
                                    </g>
                                </svg>
                            </div>
                        </Link>

                        <IconButton onClick={handleOpen} sx={{ color: "#fff", "&:hover": { color: "primary.light" } }}>
                            <GlobeIcon fontSize="large" />
                        </IconButton>

                        <Modal open={open} onClose={handleClose}>
                            <Box sx={{ position: "absolute", top: "50%", left: "50%", transform: "translate(-50%, -50%)", width: 320, bgcolor: "background.paper", borderRadius: 2, boxShadow: 24, p: 4, display: "flex", flexDirection: "column", alignItems: "center" }}>
                                <h2>Выберите язык</h2>
                                <Stack direction="row" spacing={2}>
                                    <Button variant={siteLanguage === "ru" ? "contained" : "outlined"} onClick={() => { setSiteLanguage("ru"); handleClose(); }}>
                                        <Flag code="RU" height={20}/> Русский
                                    </Button>
                                    <Button variant={siteLanguage === "en" ? "contained" : "outlined"} onClick={() => { setSiteLanguage("en"); handleClose(); }}>
                                        <Flag code="US" height={20} /> English
                                    </Button>
                                </Stack>
                            </Box>
                        </Modal>
                    </div>

                    <div className="nav__bottom-txt">
                        <h4>{headerText}</h4>
                        <IconButton color="inherit" onClick={openSearchMenu}>
                            <SearchIcon />
                        </IconButton>
                    </div>
                </div>
            </nav>

            {/* Окно поиска */}
            {isSearchOpen && (
                <Box
                    sx={{
                        position: "fixed",
                        top: 0,
                        left: 0,
                        width: "100%",
                        height: "100%",
                        backgroundColor: "rgba(0, 0, 0, 0.8)",
                        zIndex: 1200,
                        display: "flex",
                        flexDirection: "column",
                        alignItems: "center",
                        paddingTop: "20px",
                        color: "white",
                    }}
                >
                    <IconButton
                        color="inherit"
                        onClick={closeSearchMenu}
                        sx={{ position: "absolute", top: "10px", right: "10px" }}
                    >
                        <CloseIcon />
                    </IconButton>

                    <InputBase
                        autoFocus
                        placeholder="Введите название товара"
                        value={searchQuery}
                        onChange={handleSearchChange}
                        sx={{
                            backgroundColor: "white",
                            color: "black",
                            borderRadius: "8px",
                            width: "80%",
                            maxWidth: "500px",
                            padding: "8px 16px",
                            marginBottom: "16px",
                        }}
                    />

                    {isLoading ? (
                        <CircularProgress color="inherit" />
                    ) : (
                        <Container>
                        {filteredResults.length > 0 ? (
    filteredResults.map((item) => (
        <Box
            key={item.id}
            sx={{
                backgroundColor: "white",
                color: "black",
                padding: "8px",
                borderRadius: "8px",
                marginBottom: "8px",
                cursor: "pointer",
            }}
            onClick={() => {
                console.log("Выбранный товар:", item);
                closeSearchMenu();
                navigate(`/shop/${item.website_url}/category/${item.category_id}/item/${item.id}`);
            }}
        >
            <Typography variant="h6">{item.name}</Typography>
            <Typography variant="body2">{item.price} ₽</Typography>
        </Box>
    ))
) : (
    <Typography variant="h6" align="center">
        Ничего не найдено
    </Typography>
)}

                        </Container>
                    )}
                </Box>
            )}
        </div>
    );
};

export default NavbarList;
