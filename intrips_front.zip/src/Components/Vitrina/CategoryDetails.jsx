import React, { useEffect, useState } from "react";
import {
  AppBar,
  Toolbar,
  IconButton,
  Typography,
  Tabs,
  Tab,
  Card,
  CardContent,
  CardMedia,
  Grid,
  Container,
  Badge,
  Button,
} from "@mui/material";
import ArrowBackIcon from "@mui/icons-material/ArrowBack";
import ShoppingCartIcon from "@mui/icons-material/ShoppingCart";
import { useNavigate, useParams } from "react-router-dom";
import { useCart } from "react-use-cart";
import Footer from "../Footer/Footer";
import "./style.css";
import ClientChat from "../Chat/ClientChat";

const CategoryDetails = () => {
  const { website_url, category_id } = useParams();
  const navigate = useNavigate();
  const { addItem, getItem, updateItemQuantity, totalItems } = useCart();

  const [shop, setShop] = useState(null);
  const [selectedCategory, setSelectedCategory] = useState(parseInt(category_id));
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [siteLanguage, setSiteLanguage] = useState("ru");

  useEffect(() => {
    if (!website_url) {
      setError("Ошибка: Некорректный URL магазина");
      setLoading(false);
      return;
    }

    fetch("https://intrips.site/api/all-data/")
      .then((response) => response.json())
      .then((data) => {
        const selectedShop = data.find(
          (item) => item.user_settings && item.user_settings.website_url === website_url
        );

        if (!selectedShop) {
          setError("Магазин не найден");
          setLoading(false);
          return;
        }

        setShop(selectedShop);
        setLoading(false);
      })
      .catch(() => {
        setError("Ошибка загрузки данных");
        setLoading(false);
      });
  }, [website_url]);

  useEffect(() => {
    setSelectedCategory(parseInt(category_id));
  }, [category_id]);

  if (loading) return <p>Загрузка...</p>;
  if (error) return <p>{error}</p>;

  const categories = shop.categories.filter(
    (category) =>
      category.sub_category.id === shop.categories.find((c) => c.id === selectedCategory)?.sub_category?.id
  );

  const filteredMenuItems = shop.menu_items.filter((item) => item.category.id === selectedCategory);
  console.log(filteredMenuItems);
  
  // Добавление товара в корзину с учетом магазина
  const handleAddToCart = (item) => {
    addItem(
      {
        id: `${website_url}-${item.id}`,
        name: item.name,
        price: parseFloat(item.price),
        image: item.photo,
        website_url,
      },
      1
    );
  };

  // Обновление количества товаров в корзине
  const handleUpdateQuantity = (item, newQuantity) => {
    updateItemQuantity(`${website_url}-${item.id}`, newQuantity);
  };

  return (
    <>
      <div className="view__block-main">
        <Container maxWidth="sm" style={{ padding: "0", backgroundColor: "#f9f9f9" }}>
          <AppBar position="static" color="transparent" elevation={0}>
            <Toolbar>
              <IconButton edge="start" color="inherit" onClick={() => navigate(-1)}>
                <ArrowBackIcon />
              </IconButton>
              <Typography variant="h6" style={{ flexGrow: 1 }}>
                {siteLanguage === "en"
                  ? categories.find((c) => c.id === selectedCategory)?.name_en
                  : categories.find((c) => c.id === selectedCategory)?.name}
              </Typography>
              <IconButton color="inherit" onClick={() => navigate(`/shop/${website_url}/cart`)}>
                <Badge badgeContent={totalItems} color="error">
                  <ShoppingCartIcon />
                </Badge>
              </IconButton>
            </Toolbar>
          </AppBar>

          <Tabs
            value={selectedCategory}
            onChange={(event, newValue) => setSelectedCategory(newValue)}
            variant="scrollable"
            scrollButtons="auto"
            textColor="inherit"
            indicatorColor="primary"
          >
            {categories.map((category) => (
              <Tab key={category.id} label={siteLanguage === "en" ? category.name_en : category.name} value={category.id} />
            ))}
          </Tabs>

          <Grid container spacing={2} style={{ padding: "16px" }}>
            {filteredMenuItems.map((item) => {
              const cartItem = getItem(`${website_url}-${item.id}`);
              const quantity = cartItem ? cartItem.quantity : 0;

              return (
                <Grid item xs={6} sm={6} key={item.id}>
                  <Card
                    style={{
                      display: "flex",
                      flexDirection: "column",
                      alignItems: "start",
                      backgroundColor: "#F5F5F5",
                      borderRadius: "12px",
                      boxShadow: "none",
                    }}
                  >
                    <CardMedia
                      component="img"
                      style={{
                        width: "100%",
                        height: 140,
                        objectFit: "cover",
                        borderRadius: "8px",
                      }}
                      image={`https://intrips.site${item.photo}`}
                      alt={item.photo}
                      onClick={() => navigate(`/shop/${website_url}/category/${selectedCategory}/item/${item.id}`)}
                    />
                    <CardContent style={{ flex: "1", textAlign: "center", padding: "15px 10px" }}>
                      <Typography variant="h7" style={{ fontWeight: "400", color: "#000" }}>
                        {siteLanguage === "en" ? item.name_en : item.name}
                      </Typography>
                    </CardContent>

                    {quantity > 0 ? (
                      <div
                        style={{
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "center",
                          width: "100%",
                          marginTop: "15px",
                        }}
                      >
                        <Button
                          variant="contained"
                          style={{
                            minWidth: "36px",
                            backgroundColor: "#000",
                            color: "#FFF",
                            borderRadius: "50%",
                          }}
                          onClick={() => handleUpdateQuantity(item, quantity - 1)}
                        >
                          -
                        </Button>
                        <Typography variant="h6" style={{ margin: "0 10px", fontWeight: "700" }}>
                          {quantity}
                        </Typography>
                        <Button
                          variant="contained"
                          style={{
                            minWidth: "36px",
                            backgroundColor: "#000",
                            color: "#FFF",
                            borderRadius: "50%",
                          }}
                          onClick={() => handleUpdateQuantity(item, quantity + 1)}
                        >
                          +
                        </Button>
                      </div>
                    ) : (
                      <Button
                        variant="contained"
                        className="View-product__btn-card"
                        style={{
                          marginTop: "8px",
                          backgroundColor: "#000",
                          color: "#FFF",
                          fontWeight: "700",
                          letterSpacing: "0.75px",
                          fontSize: "18px",
                          borderRadius: "24px",
                        }}
                        onClick={() => handleAddToCart(item)}
                      >
                        {item.price} ₽
                      </Button>
                    )}
                  </Card>
                </Grid>
              );
            })}
          </Grid>
        </Container>
      </div>
      <Footer websiteUrl={website_url}/>
      <ClientChat websiteUrl={website_url} className="chat-component" />
    </>
  );
};

export default CategoryDetails;
