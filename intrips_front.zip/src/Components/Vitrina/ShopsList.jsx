import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";

const ShopsList = () => {
    const [shops, setShops] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        fetch("https://intrips.site/api/all-data/")
            .then(response => response.json())
            .then(data => {
                console.log("Полученные данные:", data);
                setShops(data);
                setLoading(false);
            })
            .catch(() => {
                setError("Ошибка загрузки данных");
                setLoading(false);
            });
    }, []);

    if (loading) return <div style={{ textAlign: 'center', padding: '20px' }}>Загрузка...</div>;
    if (error) return <div style={{ color: 'red', textAlign: 'center', padding: '20px' }}>{error}</div>;

    return (
      <>
      
      <h2>Список магазинов</h2>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '20px', padding: '20px' }}>
        
        {shops.map((shop, index) => (
            <Link key={shop.user_settings.website_url || index} to={`/shop/${shop.user_settings.website_url}`} style={{ textDecoration: 'none' }}>
                <div style={{ padding: '20px', border: '1px solid #ccc', borderRadius: '10px', textAlign: 'center', transition: 'box-shadow 0.3s', cursor: 'pointer' }}
                     onMouseOver={(e) => e.currentTarget.style.boxShadow = '0 4px 8px rgba(0, 0, 0, 0.2)'}
                     onMouseOut={(e) => e.currentTarget.style.boxShadow = 'none'}>
                    <p style={{ fontSize: '16px', fontWeight: 'bold', color: '#333' }}>{shop.user_settings.website_url}</p>
                </div>
            </Link>
        ))}
    </div>
      </>
    );
};

export default ShopsList;