import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import axios from "axios";
import { useCart } from "react-use-cart";
import {
  AppBar,
  Toolbar,
  IconButton,
  Typography,
  Container,
  Button,
  Box,
  Badge,
} from "@mui/material";
import ArrowBackIcon from "@mui/icons-material/ArrowBack";
import AddIcon from "@mui/icons-material/Add";
import RemoveIcon from "@mui/icons-material/Remove";
import ShoppingCartIcon from "@mui/icons-material/ShoppingCart";
import Footer from "../Footer/Footer";
import "./style.css";
import ClientChat from "../Chat/ClientChat";

export default function ItemDetails() {
  const { website_url, item_id, id } = useParams(); // Берем URL магазина и ID товара
  const navigate = useNavigate();
  const { addItem, totalItems } = useCart();
  const [item, setItem] = useState(null);
  const [quantity, setQuantity] = useState(1);
  const siteLanguage = localStorage.getItem("siteLanguage") || "ru";

  console.log("item получен websiteUrl:", website_url);
  useEffect(() => {
    console.log("Запрашиваем данные...");

    axios
      .get("https://intrips.site/api/all-data/")
      .then((response) => {
        console.log("Ответ сервера:", response.data);

        const shop = response.data.find(
          (s) => s.user_settings && s.user_settings.website_url === website_url
        );
        if (!shop) {
          console.warn("Магазин не найден!");
          return;
        }

        console.log("Магазин найден:", shop);

        const foundItem = shop.menu_items.find(
          (menuItem) => menuItem.id === parseInt(item_id)
        ); // Исправили `id` на `item_id`

        if (foundItem) {
          console.log("Товар найден:", foundItem);
          setItem({
            ...foundItem,
            name: siteLanguage === "en" ? foundItem.name_en : foundItem.name,
            description:
              siteLanguage === "en"
                ? foundItem.description_en
                : foundItem.description,
          });
        } else {
          console.warn("Товар не найден!");
        }
      })
      .catch((error) => console.error("Ошибка запроса:", error));
  }, [item_id, website_url, siteLanguage]); // Тоже заменяем `id` на `item_id`

  const increaseQuantity = () => setQuantity((prev) => prev + 1);
  const decreaseQuantity = () =>
    setQuantity((prev) => (prev > 1 ? prev - 1 : 1));

  const handleAddToCart = () => {
    if (item) {
      addItem(
        {
          id: `${website_url}-${item.id}`,
          name: item.name,
          price: parseFloat(item.price),
          image: item.photo,
          website_url, // Добавляем URL магазина в корзину
        },
        quantity
      );
    }
  };
  

  if (!item) {
    return (
      <Container
        maxWidth="sm"
        style={{ textAlign: "center", marginTop: "20px" }}
      >
        <Typography variant="h6">
          {siteLanguage === "en" ? "Loading..." : "Загрузка..."}
        </Typography>
      </Container>
    );
  }

  return (
    <>
      <Container
        maxWidth="sm"
        style={{ padding: "0", backgroundColor: "#f9f9f9" }}
      >
        <AppBar position="static" color="transparent" elevation={0}>
          <Toolbar>
            <IconButton
              edge="start"
              color="inherit"
              onClick={() => navigate(-1)}
            >
              <ArrowBackIcon />
            </IconButton>
            <Box sx={{ flexGrow: 1 }} />
    <IconButton color="inherit" onClick={() => navigate(`/shop/${website_url}/cart`)}>
      <Badge badgeContent={totalItems} color="error">
        <ShoppingCartIcon />
      </Badge>
    </IconButton>
          </Toolbar>
        </AppBar>

        <Box style={{ padding: "16px", textAlign: "center" }}>
          <Typography
            variant="h4"
            style={{ marginBottom: "16px", fontWeight: "700" }}
            className="category-view_name"
          >
            {item.name}
          </Typography>
          <Box
            style={{
              width: "100%",
              height: "220px",
              borderRadius: "12px",
              overflow: "hidden",
              marginBottom: "16px",
            }}
          >
            <img
              src={`https://intrips.site${item.photo}`}
              alt={item.name}
              style={{
                width: "100%",
                height: "100%",
                objectFit: "cover",
              }}
            />
          </Box>
          <Typography
            variant="body1"
            style={{ marginBottom: "16px", color: "#555" }}
          >
            {item.description}
          </Typography>

          <Box
            style={{
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              marginBottom: "16px",
            }}
          >
            <IconButton
              onClick={decreaseQuantity}
              style={{ backgroundColor: "#f5f5f5", padding: "10px" }}
            >
              <RemoveIcon />
            </IconButton>
            <Typography variant="h6" style={{ margin: "0 16px" }}>
              {quantity}
            </Typography>
            <IconButton
              onClick={increaseQuantity}
              style={{ backgroundColor: "#f5f5f5", padding: "10px" }}
            >
              <AddIcon />
            </IconButton>
          </Box>

          <Button
            variant="contained"
            style={{
              backgroundColor: "black",
              color: "white",
              padding: "10px 20px",
              borderRadius: "30px",
              fontWeight: "bold",
              fontSize: "16px",
              marginBottom: "16px",
            }}
            onClick={handleAddToCart}
          >
            {siteLanguage === "en" ? "Add to cart" : "Добавить"}
            <Typography variant="h6" style={{ marginLeft: "10px" }}>
              {item.price * quantity} ₽
            </Typography>
          </Button>
        </Box>
      </Container>
      
      <ClientChat websiteUrl={website_url} />
      <Footer websiteUrl={website_url}/>
    </>
  );
}
