import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import "./style.css";
import NavbarList from "./NavbarList";
import ClientChat from "../Chat/ClientChat";

import Footer from "../Footer/Footer";
import AgreementPage from "../../CartPage/AgreementPage";
import Agreement from "../Agrement/Agrenent";

const ShopDetails = () => {
  const { website_url } = useParams();
  const navigate = useNavigate();
  const [shop, setShop] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [siteLanguage, setSiteLanguage] = useState("ru");

  useEffect(() => {
    fetch("https://intrips.site/api/all-data/")
      .then((response) => response.json())
      .then((data) => {
        const selectedShop = data.find(
          (item) => item.user_settings.website_url === website_url
        );
        if (!selectedShop) {
          setError("Магазин не найден");
          setLoading(false);
          return;
        }
        setShop(selectedShop);
        setLoading(false);
      })
      .catch(() => {
        setError("Ошибка загрузки данных");
        setLoading(false);
      });
  }, [website_url]);

  if (loading) return <p>Загрузка...</p>;
  if (error) return <p>{error}</p>;

  // 🛠️ Получаем header_text (берем первую запись из header_texts)
  const headerTextData =
    shop.user_settings.header_texts.length > 0
      ? shop.user_settings.header_texts.find(
          (text) => text.user_settings === shop.user_settings.id
        )
      : null;

  const headerText = headerTextData
    ? siteLanguage === "en"
      ? headerTextData.name_en || headerTextData.name
      : headerTextData.name
    : "Магазин";

  // 🛠️ Фоновое изображение: если есть photo в header_texts, используем его, иначе - navbar_background
  const navbarImage =
    headerTextData && headerTextData.photo
      ? `https://intrips.site/${headerTextData.photo}`
      : `https://intrips.site/${shop.user_settings.navbar_background}`;

  return (
    <>
      <div>
        {/* 🛠️ Передаем headerText и navbarImage в Navbar */}
        <NavbarList
          imgUrl={navbarImage}
          headerText={headerText}
          siteLanguage={siteLanguage}
          setSiteLanguage={setSiteLanguage}
          websiteUrl={website_url} // 🛠️ Передаем URL магазина
        />

        <div className="secton1">
          <div className="container sect1_container">
            {shop.user_settings.subcategories.map((subcategory, index) => (
              <React.Fragment key={subcategory.id}>
                <div className="subcategory-section">
                  <h5 className="sect1__p1">
                    {siteLanguage === "en"
                      ? subcategory.name_en || subcategory.name
                      : subcategory.name}
                  </h5>
                  <div className="sect1__cards mt-3">
                    {shop.user_settings.categories.filter(
                      (category) => category.sub_category.id === subcategory.id
                    ).length > 0 ? (
                      shop.user_settings.categories
                        .filter(
                          (category) =>
                            category.sub_category.id === subcategory.id
                        )
                        .map((category) => (
                          <div
                            key={category.id}
                            className="sect1__card"
                            style={{
                              background: category.photo
                                ? `linear-gradient(rgba(0, 0, 0, 0.2), rgba(0, 0, 0, 0.7)), url(https://intrips.site/${category.photo})`
                                : "#ccc",
                              backgroundSize: "cover",
                              backgroundPosition: "center",
                              backgroundRepeat: "no-repeat",
                              cursor: "pointer", // добавляем указатель, чтобы было понятно, что карточка кликабельна
                            }}
                            onClick={() =>
                              navigate(
                                `/shop/${website_url}/category/${category.id}`
                              )
                            }
                          >
                            <h6>
                              {siteLanguage === "en"
                                ? category.name_en
                                : category.name}
                            </h6>
                          </div>
                        ))
                    ) : (
                      <p>Нет доступных категорий для этой подкатегории.</p>
                    )}
                  </div>
                </div>
                {index < shop.user_settings.subcategories.length - 1 && (
                  <hr className="subcategory-divider" />
                )}
              </React.Fragment>
            ))}
          </div>
          <hr className="subcategory-divider" />
        </div>
      </div>

      <Agreement shopUrl={website_url} />
      <ClientChat websiteUrl={website_url} className="chat-component" />

      <Footer websiteUrl={website_url} />
    </>
  );
};

export default ShopDetails;
