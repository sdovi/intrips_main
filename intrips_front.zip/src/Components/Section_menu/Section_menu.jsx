import React, { useEffect, useState } from "react";
import { useParams, Link, useNavigate } from "react-router-dom";

const ShopDetails = () => {
    const { website_url } = useParams();
    const navigate = useNavigate();
    const [shop, setShop] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [siteLanguage, setSiteLanguage] = useState("ru"); // Можно менять язык на "en"

    useEffect(() => {
        fetch("https://intrips.site/api/all-data/")
            .then(response => response.json())
            .then(data => {
                console.log("Полученные данные:", data);

                const selectedShop = data.find(item => item.user_settings.website_url === website_url);
                if (!selectedShop) {
                    setError("Магазин не найден");
                    setLoading(false);
                    return;
                }

                setShop(selectedShop);
                setLoading(false);
            })
            .catch(() => {
                setError("Ошибка загрузки данных");
                setLoading(false);
            });
    }, [website_url]);

    const goToCategory = (categoryId) => {
        navigate(`/shop/${website_url}/category/${categoryId}`);
    };

    if (loading) return <p>Загрузка...</p>;
    if (error) return <p>{error}</p>;

    return (
        <div className="secton1">
            <div className="container sect1_container">
                {shop.subcategories.map((subcategory, index) => (
                    <React.Fragment key={subcategory.id}>
                        <div className="subcategory-section">
                            <h5 className="sect1__p1">
                                {siteLanguage === "en" ? subcategory.name_en || subcategory.name : subcategory.name}
                            </h5>
                            <div className="sect1__cards mt-3">
                                {shop.categories.filter(category => category.sub_category.id === subcategory.id).length > 0 ? (
                                    shop.categories
                                        .filter(category => category.sub_category.id === subcategory.id)
                                        .map((category) => (
                                            <div
                                                key={category.id}
                                                className="sect1__card"
                                                onClick={() => goToCategory(category.id)}
                                                style={{
                                                    background: `linear-gradient(rgba(0, 0, 0, 0.2), rgba(0, 0, 0, 0.7)), url(${category.photo})`,
                                                    backgroundSize: "cover",
                                                    backgroundPosition: "center",
                                                    backgroundRepeat: "no-repeat",
                                                }}
                                            >
                                                <h6>{siteLanguage === "en" ? category.name_en : category.name}</h6>
                                            </div>
                                        ))
                                ) : (
                                    <p>Нет доступных категорий для этой подкатегории.</p>
                                )}
                            </div>
                        </div>
                        {/* Полоса-разделитель между подкатегориями */}
                        {index < shop.subcategories.length - 1 && <hr className="subcategory-divider" />}
                    </React.Fragment>
                ))}
            </div>
            <hr className="subcategory-divider" />
            {/* Дополнительный компонент (если он есть) */}
            {/* <AgreementList /> */}
        </div>
    );
};

export default ShopDetails;
