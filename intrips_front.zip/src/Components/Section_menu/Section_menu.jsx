import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import "./style.css";
import AgreementList from "../Agrement/Agrenent";

export default function SectionMenu() {
  const [categories, setCategories] = useState([]);
  const [subcategories, setSubcategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [siteLanguage, setSiteLanguage] = useState(localStorage.getItem("siteLanguage") || "ru");
  const navigate = useNavigate();

  useEffect(() => {
    const fetchCategoriesAndSubcategories = async () => {
      try {
        const categoryResponse = await fetch("https://intrips.site/api/categories/");
        if (!categoryResponse.ok) throw new Error("Ошибка загрузки категорий");
        const categoryData = await categoryResponse.json();

        const subcategoryResponse = await fetch("https://intrips.site/api/subcategories/");
        if (!subcategoryResponse.ok) throw new Error("Ошибка загрузки подкатегорий");
        const subcategoryData = await subcategoryResponse.json();

        setCategories(categoryData);
        setSubcategories(subcategoryData);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchCategoriesAndSubcategories();

    const handleStorageChange = () => {
      setSiteLanguage(localStorage.getItem("siteLanguage") || "ru");
    };

    window.addEventListener("storage", handleStorageChange);
    return () => window.removeEventListener("storage", handleStorageChange);
  }, []);

  const goToCategory = (id) => {
    navigate(`/products/${id}`);
  };

  if (loading) {
    return <p>Загрузка категорий...</p>;
  }

  if (error) {
    return <p>Ошибка: {error}</p>;
  }

  // Группировка категорий по подкатегориям
  const categoriesBySubcategory = subcategories.map((subcategory) => ({
    ...subcategory,
    categories: categories.filter((category) => category.sub_category === subcategory.id),
  }));

  return (
    <div className="secton1">
      <div className="container sect1_container">
        {categoriesBySubcategory.map((subcategory, index) => (
          <React.Fragment key={subcategory.id}>
            <div className="subcategory-section">
              <h5 className="sect1__p1">
                {siteLanguage === "en" ? subcategory.name_en || subcategory.name : subcategory.name}
              </h5>
              <div className="sect1__cards mt-3">
                {subcategory.categories.length > 0 ? (
                  subcategory.categories.map((category) => (
                    <div
                      key={category.id}
                      className="sect1__card"
                      onClick={() => goToCategory(category.id)}
                      style={{
                        background: `linear-gradient(rgba(0, 0, 0, 0.2), rgba(0, 0, 0, 0.7)), url(${category.photo_url})`,
                        backgroundSize: "cover",
                        backgroundPosition: "center",
                        backgroundRepeat: "no-repeat",
                      }}
                    >
                      <h6>{siteLanguage === "en" ? category.name_en : category.name}</h6>
                    </div>
                  ))
                ) : (
                  <p>Нет доступных категорий для этой подкатегории.</p>
                )}
              </div>
            </div>
            {/* Добавление полоски между подкатегориями */}
            {index < categoriesBySubcategory.length - 1 && <hr className="subcategory-divider" />}
          </React.Fragment>
        ))}
      </div>
      <hr className="subcategory-divider" />
      <AgreementList/>
    </div>
  );
  
}
